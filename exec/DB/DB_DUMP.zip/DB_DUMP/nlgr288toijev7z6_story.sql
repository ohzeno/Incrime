-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: exbodcemtop76rnz.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: nlgr288toijev7z6
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `story`
--

DROP TABLE IF EXISTS `story`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `story` (
  `story_no` int NOT NULL AUTO_INCREMENT,
  `story_nm` varchar(45) DEFAULT NULL,
  `story_difficulty` int DEFAULT NULL,
  `story_map` int DEFAULT NULL,
  `story_description` varchar(1500) DEFAULT NULL,
  PRIMARY KEY (`story_no`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `story`
--

LOCK TABLES `story` WRITE;
/*!40000 ALTER TABLE `story` DISABLE KEYS */;
INSERT INTO `story` VALUES (1,'이팀장살인사건',1,1,'2022년 5월 28일 22시 30분. 20년 전통의 중견 무역회사 중앙 인터내셔널에 화재경보와 함께 스프링클러가 터졌다. 경보 직후 모든 사람들이 대피했으나, 단 한 명 이상미 브라질 사업 담당 팀장의 모습만 보이지 않았다. 결국 이상미 팀장은 자신의 사무실 책상에 쓰러져 죽은 채 발견되었다. 아무런 외상도 없었으며 사망 추정시각은 21시 55분~22시 30분이다. 피해자 이상미 팀장은 유능함을 인정받아 입사 6년차에 과장을 달고 그 1년 후 사내 최연소 팀장으로 고속승진했으며, 철강 업계 준재벌급 집안에 학벌도 좋고 가정환경도 유복했다. 그러나 이로 인해 시기를 받기도 했고, 지나치게 원리원칙적인 FM 요소가 강한 사람이었다. 사건현장인 중앙 인터내셔널은 무역회사라는 특성상, 거래처의 현지시각에 맞춰 근무하기 때문에 직원들의 근무시간은 모두 유동적이다. 용의자는 김비서, 마이사, 윤사원, 장대행, 천보안, 최과장 이상 6명이다. 6명 중 김비서의 목숨을 앗아간 살인자가 있다. 우리는 현장을 조사해 증거를 찾고, 범인을 찾아야한다.');
/*!40000 ALTER TABLE `story` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 14:51:42
