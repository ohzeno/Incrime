-- MySQL dump 10.13  Distrib 8.0.26, for Win64 (x86_64)
--
-- Host: exbodcemtop76rnz.cbetxkdyhwsb.us-east-1.rds.amazonaws.com    Database: nlgr288toijev7z6
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `playresult`
--

DROP TABLE IF EXISTS `playresult`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `playresult` (
  `playresult_no` int NOT NULL AUTO_INCREMENT,
  `playresult_userid` varchar(16) DEFAULT NULL,
  `playresult_storyno` int DEFAULT NULL,
  `playresult_win` int DEFAULT NULL,
  PRIMARY KEY (`playresult_no`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `playresult`
--

LOCK TABLES `playresult` WRITE;
/*!40000 ALTER TABLE `playresult` DISABLE KEYS */;
INSERT INTO `playresult` VALUES (1,'1',1,1),(29,'s',1,1),(30,'a',1,0),(31,'d',1,0),(32,'f',1,0),(33,'r',1,0),(34,'q',1,0),(35,'w',1,0),(36,'s',1,0),(37,'a',1,0),(38,'r',1,0),(39,'',1,0),(40,'q',1,0),(41,'ryu',1,0),(42,'bearnote1',1,1),(43,'',1,0),(44,'1',1,0),(45,'redniche',1,0),(46,'ysik',1,0),(47,'ryu',1,0),(48,'2',1,0),(49,'ysik',1,1),(50,'bearnote1',1,0),(51,'kimjaeuk',1,0),(52,'yechankun',1,0),(53,'aaaaaaaa',1,0),(54,'ssssssss',1,0),(55,'dddddddd',1,0),(56,'ffffffff',1,0),(57,'qqqqqqqq',1,1),(58,'wwwwwwww',1,0),(59,'qqqqqqqq',1,0),(60,'wwwwwwww',1,0),(61,'aaaaaaaa',1,0),(62,'ssssssss',1,1),(63,'dddddddd',1,0),(64,'ffffffff',1,0),(65,'wwwwwwww',1,0),(66,'qqqqqqqq',1,0),(67,'kimjaeuk',1,0),(68,'aaaaaaaa',1,0),(69,'yun0522v',1,1),(70,'zenozeno',1,0),(71,'qkrtjddms27',1,0),(72,'ryukitak',1,0),(73,'yun0522v',1,1),(74,'kimjaeuk',1,0),(75,'zenozeno',1,0),(76,'yechankun',1,0);
/*!40000 ALTER TABLE `playresult` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 14:51:58
